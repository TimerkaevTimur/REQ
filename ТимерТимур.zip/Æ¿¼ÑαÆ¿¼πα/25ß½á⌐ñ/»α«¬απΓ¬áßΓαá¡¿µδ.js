document.getElementById('btn4').addEventListener('click', function() {
    console.log('Прокрутка по вертикали: ' + window.pageYOffset);
  });

  document.getElementById('btn5').addEventListener('click', function() {
    console.log('Прокрутка по горизонтали: ' + window.pageXOffset);
  });