let ol = document.getElementsByTagName('ol')[0];
let li = document.createElement('li');
li.textContent = 'пункт';
ol.appendChild(li);