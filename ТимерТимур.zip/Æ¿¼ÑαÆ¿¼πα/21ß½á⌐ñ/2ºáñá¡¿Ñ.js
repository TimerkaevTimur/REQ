let elem = document.querySelector("#elem");
elem.insertAdjacentHTML("afterend", "<span>!!!</span>");