let elem = document.querySelector("#elem");
elem.insertAdjacentHTML("afterbegin", "<span>!!!</span>");