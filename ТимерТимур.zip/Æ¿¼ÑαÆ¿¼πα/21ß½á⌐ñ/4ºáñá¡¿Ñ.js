let elem = document.querySelector("#elem");
elem.insertAdjacentHTML("beforeend", "<span>!!!</span>");