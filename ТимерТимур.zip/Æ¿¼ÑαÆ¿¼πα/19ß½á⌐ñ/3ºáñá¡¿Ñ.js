var elem = document.getElementById("elem");
var hasClass = elem.classList.contains("www");

if (hasClass) {
  console.log("Элемент имеет класс www");
} 
else {
  console.log("Элемент не имеет класс www");
}