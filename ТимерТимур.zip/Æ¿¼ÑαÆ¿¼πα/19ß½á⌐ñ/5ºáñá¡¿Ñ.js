let elem = document.getElementById("elem");
let classCount = elem.classList.length;
console.log(classCount);