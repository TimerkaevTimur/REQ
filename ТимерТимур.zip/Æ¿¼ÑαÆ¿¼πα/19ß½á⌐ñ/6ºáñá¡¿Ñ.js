let elem = document.getElementById("elem");
let classList = elem.classList;
for (let i = 0; i < classList.length; i++) {
   alert(classList.item(i));
}