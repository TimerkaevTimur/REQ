let elem = document.getElementById('elem');
let width = window.getComputedStyle(elem).width;
let height = window.getComputedStyle(elem).height;
console.log('Ширина: ' + width + ', Высота: ' + height);