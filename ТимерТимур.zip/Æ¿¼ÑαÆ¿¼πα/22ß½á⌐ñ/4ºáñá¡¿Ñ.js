let elem = document.querySelector("#elem");
let previousSibling = elem.previousElementSibling;
previousSibling.textContent += "!";