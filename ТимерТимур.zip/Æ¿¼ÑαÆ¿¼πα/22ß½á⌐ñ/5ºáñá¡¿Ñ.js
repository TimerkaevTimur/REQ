let elem = document.querySelector("#elem");
let nextSibling = elem.nextElementSibling;
nextSibling.textContent += "!";