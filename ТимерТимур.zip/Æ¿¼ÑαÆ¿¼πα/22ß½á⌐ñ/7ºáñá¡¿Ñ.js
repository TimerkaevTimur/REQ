let elem = document.querySelector("#elem");
let parent = elem.parentElement;
parent.style.color = "red";